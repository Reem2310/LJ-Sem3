def first(s):
    return s.split()[0]
    
    
