s=[3,4,5]
a=900
def hello():
    return "hello python"
